from .math_operations import add, subtract, multiply, divide

def my_cool_test_method():
    print('It works!')